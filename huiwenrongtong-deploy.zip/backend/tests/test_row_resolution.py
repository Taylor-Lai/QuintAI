import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from docnexus.ai.table_engine.core.models import (
    Constraint,
    EvidenceItem,
    EvidencePack,
    FieldSpec,
    LocationRef,
    TargetTableSpec,
    TaskSpec,
)
from docnexus.ai.table_engine.extractors import (
    _extract_records_from_paragraph_evidence,
    _extract_records_from_row_evidence,
)


class RowResolutionTests(unittest.TestCase):
    def test_default_all_dates_without_time_field_returns_clean_identity(self) -> None:
        target_table = TargetTableSpec(
            target_table_id="target-table-1",
            logical_name="covid",
            schema=[
                FieldSpec(field_id="f1", field_name="国家/地区", normalized_name="国家/地区", data_type="string", required=True),
                FieldSpec(field_id="f2", field_name="大洲", normalized_name="大洲", data_type="string", required=False),
                FieldSpec(field_id="f3", field_name="病例数", normalized_name="病例数", data_type="number", required=False),
            ],
        )
        task_spec = TaskSpec(
            task_id="task-1",
            intent="fill_table",
            target_template_id="template-1",
            target_tables=["target-table-1"],
            target_fields=["国家/地区", "大洲", "病例数"],
            constraints=[
                Constraint(
                    constraint_id="c1",
                    source="user_request",
                    kind="date_range",
                    field="日期",
                    operator="between",
                    value={"start": "2020-07-01", "end": "2020-08-31"},
                )
            ],
            task_policy="all_dates",
        )
        evidence_pack = EvidencePack(
            task_id="task-1",
            items=[
                EvidenceItem(
                    evidence_id="row-1",
                    evidence_type="row",
                    source_doc_id="source-1",
                    content={"国家/地区": "Albania", "大洲": "Europe", "日期": "2020-07-01", "病例数": 2580},
                ),
                EvidenceItem(
                    evidence_id="row-2",
                    evidence_type="row",
                    source_doc_id="source-1",
                    content={"国家/地区": "Albania", "大洲": "Europe", "日期": "2020-08-31", "病例数": 9513},
                ),
            ],
        )

        records = _extract_records_from_row_evidence(target_table, task_spec, evidence_pack)

        # all_dates returns all rows with clean (un-corrupted) identity field values
        self.assertEqual(len(records), 2)
        self.assertEqual(records[0].values["国家/地区"], "Albania")
        self.assertEqual(records[1].values["国家/地区"], "Albania")

    def test_latest_policy_without_time_field_uses_latest_row_per_identity(self) -> None:
        target_table = TargetTableSpec(
            target_table_id="target-table-1",
            logical_name="covid",
            schema=[
                FieldSpec(field_id="f1", field_name="国家/地区", normalized_name="国家/地区", data_type="string", required=True),
                FieldSpec(field_id="f2", field_name="大洲", normalized_name="大洲", data_type="string", required=False),
                FieldSpec(field_id="f3", field_name="病例数", normalized_name="病例数", data_type="number", required=False),
            ],
        )
        task_spec = TaskSpec(
            task_id="task-1",
            intent="fill_table",
            target_template_id="template-1",
            target_tables=["target-table-1"],
            target_fields=["国家/地区", "大洲", "病例数"],
            constraints=[
                Constraint(
                    constraint_id="c1",
                    source="user_request",
                    kind="date_range",
                    field="日期",
                    operator="between",
                    value={"start": "2020-07-01", "end": "2020-08-31"},
                )
            ],
            task_policy="latest",
        )
        evidence_pack = EvidencePack(
            task_id="task-1",
            items=[
                EvidenceItem(
                    evidence_id="row-1",
                    evidence_type="row",
                    source_doc_id="source-1",
                    content={"国家/地区": "Albania", "大洲": "Europe", "日期": "2020-07-01", "病例数": 2580},
                ),
                EvidenceItem(
                    evidence_id="row-2",
                    evidence_type="row",
                    source_doc_id="source-1",
                    content={"国家/地区": "Albania", "大洲": "Europe", "日期": "2020-08-31", "病例数": 9513},
                ),
                EvidenceItem(
                    evidence_id="row-3",
                    evidence_type="row",
                    source_doc_id="source-1",
                    content={"国家/地区": "Ireland", "大洲": "Europe", "日期": "2020-08-31", "病例数": 28811},
                ),
            ],
        )

        records = _extract_records_from_row_evidence(target_table, task_spec, evidence_pack)

        self.assertEqual(len(records), 2)
        values_by_country = {record.values["国家/地区"]: record.values for record in records}
        self.assertEqual(values_by_country["Albania"]["病例数"], 9513)
        self.assertEqual(values_by_country["Ireland"]["病例数"], 28811)

    def test_date_range_with_time_field_keeps_multiple_rows(self) -> None:
        target_table = TargetTableSpec(
            target_table_id="target-table-1",
            logical_name="daily-table",
            schema=[
                FieldSpec(field_id="f1", field_name="国家/地区", normalized_name="国家/地区", data_type="string", required=True),
                FieldSpec(field_id="f2", field_name="日期", normalized_name="日期", data_type="string", required=True),
                FieldSpec(field_id="f3", field_name="病例数", normalized_name="病例数", data_type="number", required=False),
            ],
        )
        task_spec = TaskSpec(
            task_id="task-1",
            intent="fill_table",
            target_template_id="template-1",
            target_tables=["target-table-1"],
            target_fields=["国家/地区", "日期", "病例数"],
            constraints=[
                Constraint(
                    constraint_id="c1",
                    source="user_request",
                    kind="date_range",
                    field="日期",
                    operator="between",
                    value={"start": "2020-07-01", "end": "2020-08-31"},
                )
            ],
            task_policy="all_dates",
        )
        evidence_pack = EvidencePack(
            task_id="task-1",
            items=[
                EvidenceItem(
                    evidence_id="row-1",
                    evidence_type="row",
                    source_doc_id="source-1",
                    content={"国家/地区": "Albania", "日期": "2020-07-01", "病例数": 2580},
                ),
                EvidenceItem(
                    evidence_id="row-2",
                    evidence_type="row",
                    source_doc_id="source-1",
                    content={"国家/地区": "Albania", "日期": "2020-08-31", "病例数": 9513},
                ),
            ],
        )

        records = _extract_records_from_row_evidence(target_table, task_spec, evidence_pack)

        self.assertEqual(len(records), 2)
        self.assertEqual(records[0].values["日期"], "2020-07-01")
        self.assertEqual(records[1].values["日期"], "2020-08-31")

    def test_covid_docx_schema_extraction_builds_country_record(self) -> None:
        target_table = TargetTableSpec(
            target_table_id="target-table-1",
            logical_name="covid",
            schema=[
                FieldSpec(field_id="f1", field_name="国家/地区", normalized_name="国家/地区", data_type="string", required=True),
                FieldSpec(field_id="f2", field_name="大洲", normalized_name="大洲", data_type="string", required=False),
                FieldSpec(field_id="f3", field_name="人均GDP", normalized_name="人均GDP", data_type="number", required=False),
                FieldSpec(field_id="f4", field_name="人口", normalized_name="人口", data_type="number", required=False),
                FieldSpec(field_id="f5", field_name="每日检测数", normalized_name="每日检测数", data_type="number", required=False),
                FieldSpec(field_id="f6", field_name="病例数", normalized_name="病例数", data_type="number", required=False),
            ],
        )
        task_spec = TaskSpec(
            task_id="task-1",
            intent="fill_table",
            target_template_id="template-1",
            target_tables=["target-table-1"],
            target_fields=["国家/地区", "大洲", "人均GDP", "人口", "每日检测数", "病例数"],
            task_policy="all_dates",
        )
        evidence_pack = EvidencePack(
            task_id="task-1",
            items=[
                EvidenceItem("p0", "paragraph", "docx-1", "2020 年 7 月 27 日中国各省新冠疫情全景纪实"),
                EvidenceItem("p1", "paragraph", "docx-1", "Asia（亚洲）"),
                EvidenceItem("p2", "paragraph", "docx-1", "当日全国新增确诊病例 68 例。"),
                EvidenceItem("p3", "paragraph", "docx-1", "湖北省"),
                EvidenceItem("p4", "paragraph", "docx-1", "常住人口约 5775 万人，人均 GDP 约 7.3 万元，当日核酸检测量约 12.6 万份。"),
                EvidenceItem("p5", "paragraph", "docx-1", "广东省"),
                EvidenceItem("p6", "paragraph", "docx-1", "常住人口约 1.26 亿，人均 GDP 约 9.6 万元，当日核酸检测量约 38.2 万份。"),
            ],
        )

        records = _extract_records_from_paragraph_evidence(target_table, task_spec, evidence_pack)

        self.assertEqual(len(records), 1)
        record = records[0]
        # Identity field is not corrupted with date suffix
        self.assertEqual(record.values["国家/地区"], "China")
        self.assertEqual(record.values["大洲"], "Asia")
        self.assertEqual(record.values["病例数"], 68)
        self.assertTrue(record.values["人口"])
        self.assertTrue(any("Synthesized country-level record" in note for note in record.notes))

    def test_covid_docx_schema_extraction_builds_china_daily_records_when_date_required(self) -> None:
        target_table = TargetTableSpec(
            target_table_id="target-table-1",
            logical_name="covid",
            schema=[
                FieldSpec(field_id="f1", field_name="国家/地区", normalized_name="国家/地区", data_type="string", required=True),
                FieldSpec(field_id="f2", field_name="大洲", normalized_name="大洲", data_type="string", required=False),
                FieldSpec(field_id="f3", field_name="人均GDP", normalized_name="人均GDP", data_type="number", required=False),
                FieldSpec(field_id="f4", field_name="人口", normalized_name="人口", data_type="number", required=False),
                FieldSpec(field_id="f5", field_name="日期", normalized_name="日期", data_type="date", required=True),
                FieldSpec(field_id="f6", field_name="每日检测数", normalized_name="每日检测数", data_type="number", required=False),
                FieldSpec(field_id="f7", field_name="病例数", normalized_name="病例数", data_type="number", required=False),
            ],
        )
        task_spec = TaskSpec(
            task_id="task-1",
            intent="fill_table",
            target_template_id="template-1",
            target_tables=["target-table-1"],
            target_fields=["国家/地区", "大洲", "人均GDP", "人口", "日期", "每日检测数", "病例数"],
            constraints=[
                Constraint(
                    constraint_id="c1",
                    source="user_request",
                    kind="date_range",
                    field="日期",
                    operator="between",
                    value={"start": "2020-07-01", "end": "2020-08-31"},
                )
            ],
            task_policy="all_dates",
        )
        evidence_pack = EvidencePack(
            task_id="task-1",
            items=[
                EvidenceItem("p0", "paragraph", "china-docx", "2020 年 7 月 27 日中国各省新冠疫情全景纪实"),
                EvidenceItem("p1", "paragraph", "china-docx", "Asia（亚洲）"),
                EvidenceItem("p2", "paragraph", "china-docx", "当日全国新增确诊病例 68 例。"),
                EvidenceItem("p3", "paragraph", "china-docx", "2020 年 8 月 1 日中国新冠疫情通报"),
                EvidenceItem("p4", "paragraph", "china-docx", "当日全国新增确诊病例 45 例。"),
                EvidenceItem("p5", "paragraph", "china-docx", "湖北省"),
                EvidenceItem("p6", "paragraph", "china-docx", "常住人口约 5775 万人，人均 GDP 约 7.3 万元，当日核酸检测量约 12.6 万份。"),
            ],
        )

        records = _extract_records_from_paragraph_evidence(target_table, task_spec, evidence_pack)

        self.assertEqual(
            [(record.values["国家/地区"], record.values["日期"], record.values["病例数"]) for record in records],
            [("China", "2020-07-27", 68), ("China", "2020-08-01", 45)],
        )
        self.assertTrue(all(record.values["大洲"] == "Asia" for record in records))

    def test_covid_docx_extraction_restores_document_order_after_rag_ranking(self) -> None:
        target_table = TargetTableSpec(
            target_table_id="target-table-1",
            logical_name="covid",
            schema=[
                FieldSpec("f1", "国家/地区", "国家/地区", "string", True),
                FieldSpec("f2", "大洲", "大洲", "string", False),
                FieldSpec("f3", "人均GDP", "人均GDP", "number", False),
                FieldSpec("f4", "人口", "人口", "number", False),
                FieldSpec("f5", "日期", "日期", "date", True),
                FieldSpec("f6", "每日检测数", "每日检测数", "number", False),
                FieldSpec("f7", "病例数", "病例数", "number", False),
            ],
        )
        task_spec = TaskSpec(
            "task-1", "fill_table", "template-1",
            target_fields=[field.field_name for field in target_table.schema],
        )
        contents = [
            "2020 年 7 月 27 日中国各省新冠疫情全景纪实",
            "Asia（亚洲）",
            "当日全国新增确诊病例 68 例。",
            "湖北省",
            "常住人口约 5775 万人，人均 GDP 约 7.3 万元，当日核酸检测量约 12.6 万份。",
            "2020 年 8 月 1 日中国新冠疫情通报",
            "当日全国新增确诊病例 45 例。",
        ]
        ranked_order = [4, 0, 1, 2, 3, 5, 6]
        evidence_pack = EvidencePack(
            task_id="task-1",
            items=[
                EvidenceItem(
                    f"p{index}", "paragraph", "china-docx", contents[index],
                    location=LocationRef("china-docx", paragraph_index=index),
                )
                for index in ranked_order
            ],
        )

        records = _extract_records_from_paragraph_evidence(target_table, task_spec, evidence_pack)

        self.assertEqual([record.values["病例数"] for record in records], [68, 45])
        self.assertTrue(all(record.values["人口"] == 57750000 for record in records))
        self.assertTrue(all(record.values["人均GDP"] == 73000 for record in records))
        self.assertTrue(all(record.values["每日检测数"] == 126000 for record in records))


if __name__ == "__main__":
    unittest.main()
